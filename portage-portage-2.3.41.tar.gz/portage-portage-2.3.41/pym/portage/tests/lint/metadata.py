# Copyright 2015 Gentoo Foundation
# Distributed under the terms of the GNU General Public License v2

module_metadata = {
}

script_metadata = {
	'socks5-server.py': {
		'required_python': '3.3',
	},
}
